import type { NextConfig } from "next";
import path from "path";

const nextConfig: NextConfig = {
  outputFileTracingRoot: path.join(__dirname),
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'cis-peppcruise-buckets.s3.eu-north-1.amazonaws.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'res.cloudinary.com',
        pathname: '/**', // Matches all paths under this domain
      },
      {
        protocol: "https",
        hostname: "www.peppcruise.com",
        pathname: "/images/**",
      },
      {
        protocol: 'https',
        hostname: 'cdn.peppcruise.com',
        port: '',
        pathname: '/**',
      },
    ],
  },
};

export default nextConfig;

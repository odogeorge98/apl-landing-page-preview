import { redirect } from "next/navigation";

export default function LegacySupportPage() {
  redirect("/dashboard/support");
}
